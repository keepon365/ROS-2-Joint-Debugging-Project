#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Int8, Float32, Bool
import tkinter as tk
from tkinter import ttk

class LEDGui(Node):
    def __init__(self):
        super().__init__('led_gui')

        # ROS 2 发布者
        self.switch_pub = self.create_publisher(Int8, '/cmd_led_switch', 10)
        self.brightness_pub = self.create_publisher(Float32, '/cmd_led_brightness', 10)

        # 订阅 GPIO 状态
        self.gpio_sub = self.create_subscription(
            Bool, '/gpio_state', self.gpio_callback, 10)

        # 初始化 Tkinter 窗口
        self.root = tk.Tk()
        self.root.title('LED 遥控器')
        self.root.geometry('350x250')
        self.root.resizable(False, False)

        # ---------- 开关控制区 ----------
        frame_switch = ttk.LabelFrame(self.root, text='灯光控制', padding=10)
        frame_switch.pack(fill='x', padx=10, pady=5)

        btn_on = ttk.Button(frame_switch, text='🔆 开灯', command=self.send_on)
        btn_on.pack(side='left', padx=5)

        btn_off = ttk.Button(frame_switch, text='🔅 关灯', command=self.send_off)
        btn_off.pack(side='left', padx=5)

        btn_toggle = ttk.Button(frame_switch, text='🔄 反转', command=self.send_toggle)
        btn_toggle.pack(side='left', padx=5)

        # ---------- 亮度滑动条 ----------
        frame_bright = ttk.LabelFrame(self.root, text='亮度调节', padding=10)
        frame_bright.pack(fill='x', padx=10, pady=5)

        self.brightness_var = tk.DoubleVar(value=1.0)
        scale = ttk.Scale(
            frame_bright, from_=0.0, to=1.0, variable=self.brightness_var,
            orient='horizontal', length=200, command=self.send_brightness)
        scale.pack(anchor='center')

        # ---------- GPIO 状态显示 ----------
        frame_gpio = ttk.LabelFrame(self.root, text='GPIO 引脚状态', padding=10)
        frame_gpio.pack(fill='x', padx=10, pady=5)

        self.gpio_label = ttk.Label(frame_gpio, text='等待数据...', font=('Arial', 14))
        self.gpio_label.pack()

        # 定时更新ROS，防止界面卡死
        self.update_ros()

    # ---------- 按钮回调 ----------
    def send_on(self):
        msg = Int8(data=1)
        self.switch_pub.publish(msg)
        self.get_logger().info('发布开灯指令')

    def send_off(self):
        msg = Int8(data=0)
        self.switch_pub.publish(msg)
        self.get_logger().info('发布关灯指令')

    def send_toggle(self):
        msg = Int8(data=2)
        self.switch_pub.publish(msg)
        self.get_logger().info('发布反转指令')

    def send_brightness(self, event=None):
        val = float(self.brightness_var.get())
        msg = Float32(data=val)
        self.brightness_pub.publish(msg)
        self.get_logger().info(f'发布亮度 {val:.2f}')

    # ---------- GPIO 状态订阅回调 ----------
    def gpio_callback(self, msg):
        if msg.data:
            self.gpio_label.config(text='🔴 高电平 (True)', foreground='red')
        else:
            self.gpio_label.config(text='🔵 低电平 (False)', foreground='blue')

    # ---------- 定时调用 ROS spin_once 以处理订阅消息 ----------
    def update_ros(self):
        rclpy.spin_once(self, timeout_sec=0.01)
        self.root.after(10, self.update_ros)

    def run(self):
        self.root.mainloop()

def main(args=None):
    rclpy.init(args=args)
    gui = LEDGui()
    gui.run()
    gui.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
