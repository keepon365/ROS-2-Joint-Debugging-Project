#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Int8, Float32, String
import json
import time
import os

class MissionExecutor(Node):
    def __init__(self):
        super().__init__('mission_executor_node')

        # 声明参数：mission.json 的路径（默认在包目录下）
        self.declare_parameter('mission_file', '')
        mission_file = self.get_parameter('mission_file').value

        if not mission_file:
            # 如果未指定路径，则使用包路径下的 mission.json
            mission_file = 'mission.json'

        # 发布者
        self.switch_pub = self.create_publisher(Int8, '/cmd_led_switch', 10)
        self.brightness_pub = self.create_publisher(Float32, '/cmd_led_brightness', 10)
        self.done_pub = self.create_publisher(String, '/mission_done', 10)

        # 读取任务文件
        try:
            with open(mission_file, 'r') as f:
                self.tasks = json.load(f)
            self.get_logger().info(f'成功加载任务文件: {mission_file}')
        except Exception as e:
            self.get_logger().error(f'无法读取任务文件 {mission_file}: {e}')
            self.tasks = []

        # 开始执行任务
        self.execute_tasks()

    def execute_tasks(self):
        for task in self.tasks:
            cmd = task.get('cmd', '').lower()
            delay = task.get('delay', 0.0)

            if cmd == 'on':
                self.get_logger().info('执行：开灯')
                self.switch_pub.publish(Int8(data=1))
            elif cmd == 'off':
                self.get_logger().info('执行：关灯')
                self.switch_pub.publish(Int8(data=0))
            elif cmd == 'brightness':
                value = float(task.get('value', 1.0))
                self.get_logger().info(f'执行：亮度 {value}')
                self.brightness_pub.publish(Float32(data=value))
            elif cmd == 'blink':
                times = int(task.get('times', 1))
                interval = float(task.get('interval', 0.5))
                self.get_logger().info(f'执行：闪烁 {times} 次，间隔 {interval} 秒')
                for i in range(times):
                    self.switch_pub.publish(Int8(data=1))
                    time.sleep(interval)
                    self.switch_pub.publish(Int8(data=0))
                    if i < times - 1:
                        time.sleep(interval)
            else:
                self.get_logger().warn(f'未知指令: {cmd}，跳过')

            # 每条指令执行后等待 delay 秒
            if delay > 0:
                self.get_logger().info(f'等待 {delay} 秒...')
                time.sleep(delay)

        # 任务序列全部完成
        self.get_logger().info('所有任务完成，发布 /mission_done')
        self.done_pub.publish(String(data='done'))
        # 优雅退出
        rclpy.shutdown()

def main(args=None):
    rclpy.init(args=args)
    node = MissionExecutor()
    # 节点在构造函数中自动执行完毕并退出，这里不需要 spin
    node.destroy_node()

if __name__ == '__main__':
    main()
