#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Int8, Float32, Bool
import serial
import struct
import threading
import time

class SerialDriver(Node):
    def __init__(self):
        super().__init__('serial_driver')

        # 声明参数：串口号、波特率
        self.declare_parameter('port', '/dev/ttyUSB0')
        self.declare_parameter('baudrate', 115200)
        port = self.get_parameter('port').value
        baudrate = self.get_parameter('baudrate').value

        # 打开串口
        try:
            self.ser = serial.Serial(port, baudrate, timeout=0.05)
            self.get_logger().info(f'串口 {port} 打开成功')
        except Exception as e:
            self.get_logger().fatal(f'无法打开串口: {e}')
            raise SystemExit

        # 订阅：接收开灯、亮度指令
        self.sub_switch = self.create_subscription(Int8, 'cmd_led_switch', self.cb_switch, 10)
        self.sub_bright = self.create_subscription(Float32, 'cmd_led_brightness', self.cb_brightness, 10)

        # 发布：上报 GPIO 状态
        self.pub_gpio = self.create_publisher(Bool, 'gpio_state', 10)

        # 上行解析状态机
        self.rx_state = 'WAIT_H1'
        self.rx_buf = bytearray()
        self.rx_thread = threading.Thread(target=self.read_serial, daemon=True)
        self.rx_thread.start()

    # ---------- 通信协议内部实现 ----------
    def calc_checksum(self, data):
        return sum(data) & 0xFF

    def send_frame(self, cmd, payload):
        frame = bytearray([0x5A, 0xA5, cmd])
        frame.extend(payload)
        frame.append(self.calc_checksum(frame))
        self.ser.write(frame)
        self.get_logger().debug(f'发送帧: {frame.hex()}')

    # ---------- 话题回调：把ROS2消息翻译成串口帧 ----------
    def cb_switch(self, msg: Int8):
        if msg.data in (0, 1, 2):
            self.send_frame(0x01, bytes([msg.data]))
            self.get_logger().info(f'LED 开关: {msg.data}')
        else:
            self.get_logger().warn('无效开关值')

    def cb_brightness(self, msg: Float32):
        val = max(0.0, min(1.0, msg.data))
        payload = struct.pack('<f', val)   # 4字节小端float
        self.send_frame(0x02, payload)
        self.get_logger().info(f'LED 亮度: {val:.2f}')

    # ---------- 上行帧解析：把串口帧翻译成ROS2消息 ----------
    def parse_byte(self, byte):
        if self.rx_state == 'WAIT_H1':
            if byte == 0x5A:
                self.rx_buf = bytearray([0x5A])
                self.rx_state = 'WAIT_H2'
        elif self.rx_state == 'WAIT_H2':
            if byte == 0xA5:
                self.rx_buf.append(0xA5)
                self.rx_state = 'WAIT_GPIO'
            elif byte == 0x5A:
                self.rx_buf = bytearray([0x5A])
            else:
                self.rx_state = 'WAIT_H1'
        elif self.rx_state == 'WAIT_GPIO':
            self.rx_buf.append(byte)
            self.rx_state = 'WAIT_CHECKSUM'
        elif self.rx_state == 'WAIT_CHECKSUM':
            self.rx_buf.append(byte)
            if len(self.rx_buf)==4 and self.rx_buf[3]==self.calc_checksum(self.rx_buf[:3]):
                gpio = (self.rx_buf[2] == 0x01)
                msg = Bool(data=gpio)
                self.pub_gpio.publish(msg)
            self.rx_state = 'WAIT_H1'

    def read_serial(self):
        while rclpy.ok():
            try:
                if self.ser.in_waiting:
                    byte = self.ser.read(1)
                    if byte:
                        self.parse_byte(byte[0])
                else:
                    time.sleep(0.001)
            except Exception as e:
                self.get_logger().error(f'串口读取异常: {e}')
                break

def main(args=None):
    rclpy.init(args=args)
    node = SerialDriver()
    rclpy.spin(node)
    node.ser.close()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
