from setuptools import find_packages, setup

package_name = 'serial_driver'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='zwm',
    maintainer_email='z.7.3@qq.com',
    description='TODO: Package description',
    license='Serial driver HAL for STM32',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
    'console_scripts': [
        'serial_driver = serial_driver.serial_driver:main',
    	],
    },
)
